/**
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';
/* jshint ignore:start */
var netEvents = require('./net-events.js');
var netUtil   = require('./net-util.js');

function serverCleanupWrap(proto) {
    proto._emitCloseIfDrained = function () {
        if (!this._uvHandle && this._connections === 0) {
            process.nextTick(netUtil.emitEvent, this, netEvents.CLOSE);
        }
    };

    function cleanupUVHandle(cb) {
        if (this._uvHandle) {
            netUtil.onceListener(this, netEvents.CLOSE, cb);
            uv.close(this._uvHandle);
            this._uvHandle = null;
        }
    }

    proto.close = function(cb) {
        cleanupUVHandle.call(this, cb);
        this._emitCloseIfDrained();
    };
}

exports.serverCleanupWrap = serverCleanupWrap;