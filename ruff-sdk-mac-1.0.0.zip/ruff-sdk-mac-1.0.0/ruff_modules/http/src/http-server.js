/**
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';

/* jshint ignore:start */
var net = require('net');
var util = require('util');
var debug = util.debuglog('http');
var ServerResponse = require('./http-server-response.js');
var HTTPParser = require('./http-parser.js').HTTPParser;
var common = require('./http-common.js');
var httpSocketSetup = common.httpSocketSetup;
var parsers = common.parsers;
var freeParser = common.freeParser;
var kOnExecute = HTTPParser.kOnExecute | 0;

function onSocketResume() {
    if (this._uvHandle) {
        uv.read_start(this._uvHandle);
    }

}

function onSocketPause() {
    if (this._uvHandle) {
        uv.read_stop(this._uvHandle);
    }
}

function socketOnWrap(ev, fn) {
    var res = net.Socket.prototype.on.call(this, ev, fn);
    if (!this.parser) {
        this.on = net.Socket.prototype.on;
    }

    return res;
}

function connectionListener(socket) {
    var self = this;
    var outgoing = [];
    var incoming = [];
    var outgoingData = 0;

    function updateOutgoingData(delta) {
        // `outgoingData` is an approximate amount of bytes queued through all
        // inactive responses. If more data than the high watermark is queued - we
        // need to pause TCP socket/HTTP parser, and wait until the data will be
        // sent to the client.
        outgoingData += delta;
        if (socket._paused) {
            return socketOnDrain();
        }
    }

    function abortIncoming() {
        while (incoming.length) {
            var req = incoming.shift();
            req.emit('aborted');
            req.emit('close');
        }
        // abort socket._httpMessage ?
    }

    function socketOnError(e) {
        self.emit('clientError', e, this);
    }

    function serverSocketCloseListener() {
        debug('server socket close');
        // mark this parser as reusable
        if (this.parser) {
            freeParser(this.parser, null, this);
        }

        abortIncoming();
    }

    function socketOnEnd() {
        var socket = this;
        var ret = parser.finish();

        if (ret instanceof Error) {
            debug('parse error');
            socket.destroy(ret);
            return;
        }

        if (!self.httpAllowHalfOpen) {
            abortIncoming();
            if (socket.writable) {
                socket.end();
            }
        } else if (outgoing.length) {
            outgoing[outgoing.length - 1]._last = true;
        } else if (socket._httpMessage) {
            socket._httpMessage._last = true;
        } else {
            if (socket.writable) {
                socket.end();
            }
        }
    }

    function onParserExecute(ret, d) {
        debug('SERVER socketOnParserExecute %d', ret);
        onParserExecuteCommon(ret, undefined);
    }

    function onParserExecuteCommon(ret, d) {
        if (ret instanceof Error) {
            debug('parse error');
            socket.destroy(ret);
        } else if (parser.incoming && parser.incoming.upgrade) {
            // Upgrade or CONNECT
            var bytesParsed = ret;
            var req = parser.incoming;
            debug('SERVER upgrade or connect', req.method);

            if (!d) {
                d = parser.getCurrentBuffer();
            }

            socket.removeListener('data', socketOnData);
            socket.removeListener('end', socketOnEnd);
            socket.removeListener('close', serverSocketCloseListener);
            // parser.unconsume(socket._handle._externalStream);
            parser.finish();
            freeParser(parser, req, null);
            parser = null;

            var eventName = req.method === 'CONNECT' ? 'connect' : 'upgrade';
            if (EventEmitter.listenerCount(self, eventName) > 0) {
                debug('SERVER have listener for %s', eventName);
                var bodyHead = d.slice(bytesParsed, d.length);

                // TODO(isaacs): Need a way to reset a stream to fresh state
                // IE, not flowing, and not explicitly paused.
                socket._readableState.flowing = null;
                self.emit(eventName, req, socket, bodyHead);
            } else {
                // Got upgrade header or CONNECT method, but have no handler.
                socket.destroy();
            }
        }

        if (socket._paused) {
            // onIncoming paused the socket, we should pause the parser as well
            debug('pause parser');
            socket.parser.pause();
        }
    }

    function socketOnData(d) {
        debug('SERVER socketOnData %d', d.length);
        var ret = parser.execute(d);
        onParserExecuteCommon(ret, d, self);
    }

    function socketOnDrain() {
        var needPause = false; //outgoingData > socket._writableState.highWaterMark;

        // If we previously paused, then start reading again.
        if (socket._paused && !needPause) {
            socket._paused = false;
            socket.parser.resume();
            socket.resume();
        }
    }

    function parserOnIncoming(req, shouldKeepAlive) {
        incoming.push(req);

        // If the writable end isn't consuming, then stop reading
        // so that we don't become overwhelmed by a flood of
        // pipelined requests that may never be resolved.
        if (!socket._paused) {
            // var needPause = socket._writableState.needDrain ||
            //     outgoingData >= socket._writableState.highWaterMark;
            // if (needPause) {
            //     socket._paused = true;
            //     // We also need to pause the parser, but don't do that until after
            //     // the call to execute, because we may still be processing the last
            //     // chunk.
            //     socket.pause();
            // }
        }

        var res = new ServerResponse(req);
        res._onPendingData = updateOutgoingData;

        res.shouldKeepAlive = shouldKeepAlive;
        // DTRACE_HTTP_SERVER_REQUEST(req, socket);
        // LTTNG_HTTP_SERVER_REQUEST(req, socket);
        // COUNTER_HTTP_SERVER_REQUEST();

        if (socket._httpMessage) {
            // There are already pending outgoing res, append.
            outgoing.push(res);
        } else {
            res.assignSocket(socket);
        }

        // When we're finished writing the response, check if this is the last
        // respose, if so destroy the socket.
        res.on('finish', resOnFinish);

        function resOnFinish() {
            // Usually the first incoming element should be our request.  it may
            // be that in the case abortIncoming() was called that the incoming
            // array will be empty.

            incoming.shift();

            // if the user never called req.read(), and didn't pipe() or
            // .resume() or .on('data'), then we call req._dump() so that the
            // bytes will be pulled off the wire.
            if (!req._consuming && !req._readableState.resumeScheduled) {
                req._dump();
            }

            res.detachSocket(socket);

            if (res._last) {
                socket.destroySoon();
            } else {
                // start sending the next message
                var m = outgoing.shift();
                if (m) {
                    m.assignSocket(socket);
                }
            }
        }

        if (req.headers.expect !== undefined &&
            (req.httpVersionMajor == 1 && req.httpVersionMinor == 1) &&
            continueExpression.test(req.headers['expect'])) {
            res._expect_continue = true;
            if (EventEmitter.listenerCount(self, 'checkContinue') > 0) {
                self.emit('checkContinue', req, res);
            } else {
                res.writeContinue();
                self.emit('request', req, res);
            }
        } else {
            self.emit('request', req, res);
        }
        return false; // Not a HEAD response. (Not even a response!)
    }

    debug('SERVER new http connection');

    httpSocketSetup(socket);

    // If the user has added a listener to the server,
    // request, or response, then it's their responsibility.
    // otherwise, destroy on timeout by default
    if (self.timeout && socket.setTimeout) {
        socket.setTimeout(self.timeout);
    }

    socket.on('timeout', function() {
        var req = socket.parser && socket.parser.incoming;
        var reqTimeout = req && !req.complete && req.emit('timeout', socket);
        var res = socket._httpMessage;
        var resTimeout = res && res.emit('timeout', socket);
        var serverTimeout = self.emit('timeout', socket);

        if (!reqTimeout && !resTimeout && !serverTimeout) {
            socket.destroy();
        }
    });

    var parser = parsers.alloc();
    parser.reinitialize(HTTPParser.REQUEST);
    parser.socket = socket;
    socket.parser = parser;
    parser.incoming = null;

    // Propagate headers limit from server instance to parser
    if (typeof this.maxHeadersCount === 'number') {
        parser.maxHeaderPairs = this.maxHeadersCount << 1;
    } else {
        // Set default value because parser may be reused from FreeList
        parser.maxHeaderPairs = 2000;
    }

    socket.on('error', socketOnError);
    socket.on('close', serverSocketCloseListener);
    parser.onIncoming = parserOnIncoming;
    socket.on('end', socketOnEnd);
    socket.on('data', socketOnData);

    // We are consuming socket, so it won't get any actual data
    socket.on('resume', onSocketResume);
    socket.on('pause', onSocketPause);

    socket.on('drain', socketOnDrain);

    // Override on to unconsume on `data`, `readable` listeners
    socket.on = socketOnWrap;

    // net socket's handle has not the externalStream and the net module does not depend stream
    // var external = socket._handle._externalStream;
    // if (external)
    //     parser.consume(external);

    //external = null;
    parser[kOnExecute] = onParserExecute;

    // The following callback is issued after the headers have been read on a
    // new message. In this callback we setup the response object and pass it
    // to the user.

    socket._paused = false;
}

function Server(requestListener) {
    if (!(this instanceof Server)) {
        return new Server(requestListener);
    }

    net.Server.call(this, {
        allowHalfOpen: true
    });

    if (requestListener) {
        this.on('request', requestListener);
    }


    this.httpAllowHalfOpen = false;

    this.on('connection', connectionListener);

    this.on('clientError', function(err, conn) {
        conn.destroy(err);
    });

    this.timeout = 2 * 60 * 1000;

    this._pendingResponseData = 0;
}

util.inherits(Server, net.Server);

exports.Server = Server;
exports.ServerResponse = ServerResponse;
exports._connectionListener = connectionListener;
