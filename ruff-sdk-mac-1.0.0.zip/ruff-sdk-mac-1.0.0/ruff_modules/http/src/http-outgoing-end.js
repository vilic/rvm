/**
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';
/* jshint ignore:start */
var httpEvents = require('./http-events.js');
var common     = require('./http-common.js');
var debug = common.debug;
//var debug = console.log;

function outgoingEndWrap(proto) {
    proto.end = function (data, encoding, callback) {
        if (typeof data === 'function') {
            callback = data;
            data     = null;
        } else if (typeof encoding === 'function') {
            callback = encoding;
            encoding = null;
        }

        if (data && typeof data !== 'string' && !(data instanceof Buffer)) {
            throw new TypeError('first argument must be a string or Buffer');
        }

        if (this.finished) {
            return false;
        }

        var self = this;

        function finish() {
            self.emit(httpEvents.FINISH);
        }

        if (typeof callback === 'function') {
            this.once(httpEvents.FINISH, callback);
        }

        if (!this._header) {
            if (data) {
                if (typeof data === 'string') {
                    this._contentLength = Buffer.byteLength(data, encoding);
                } else {
                    this._contentLength = data.length;
                }
            } else {
                this._contentLength = 0;
            }
            this._implicitHeader();
        }

        if (data && !this._hasBody) {
            debug('This type of response MUST NOT have a body. ' + 'Ignoring data passed to end().');
            data = null;
        }

        if (this.connection && data) {
            this.connection.cork();
        }

        var ret;
        if (data) {
            // Normal body write.
            ret = this.write(data, encoding);
        }

        if (this._hasBody && this.chunkedEncoding) {
            ret = this._send('0\r\n' + this._trailer + '\r\n', 'binary', finish);
        } else {
            // Force a flush, HACK.
            ret = this._send('', 'binary', finish);
        }

        if (this.connection && data) {
            this.connection.uncork();
        }

        this.finished = true;

        // There is the first message on the outgoing queue, and we've sent
        // everything to the socket.
        debug('outgoing message end.');
        if (this.output.length === 0 &&
            this.connection &&
            this.connection._httpMessage === this) {
            this._finish();
        }

        return ret;
    };
}

exports.outgoingEndWrap = outgoingEndWrap;