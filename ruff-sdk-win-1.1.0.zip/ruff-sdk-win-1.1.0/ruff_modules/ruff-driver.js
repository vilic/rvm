/*!
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';
var EventEmitter  = require('events');
var inherits = require('util').inherits;
var trait = require('trait');
var include = trait.include;

function detachFunc(detach) {
    if (detach) {
        if (typeof detach !== 'function') {
            throw new TypeError('detach must be specified as a function');
        }

        return detach;
    }

    return function() {};
}

function getDeviceFunc(getDevice) {
    if (getDevice) {
        if (typeof getDevice !== 'function') {
            throw new TypeError('getDevice must be specified as a function');
        }

        return getDevice;
    }

    return function() {
        return this;
    };
}

function extend(module) {
    if (!trait.isTrait(module)) {
        module = trait(module);
    }

    trait.extend(this, module);
}

function driver(specification) {
    var Constructor = function() {
        EventEmitter.call(this);
        this.__attach__.apply(this, arguments);

        if (specification.states) {
            var self = this;
            var states = specification.states;
            Object.keys(states).forEach(function(name) {
                var state = states[name];
                Object.defineProperty(self, name, {
                    get: state
                });
            });
        }
    };

    inherits(Constructor, EventEmitter);

    var attach = specification.attach;

    if (attach === undefined || typeof attach !== 'function') {
        throw new TypeError('attach must be specified as a function');
    }

    Constructor.prototype.__attach__ = attach;
    Constructor.prototype.__detach__ = detachFunc(specification.detach);
    Constructor.prototype.__getDevice__ = getDeviceFunc(specification.getDevice);
    Constructor.prototype.extend = extend;

    // Parameters: options, context, next
    Constructor.async = attach.length >= 3;

    var exportsMethods = specification.exports;
    if (exportsMethods) {
        if (exportsMethods.extend) {
            throw new TypeError('extend is a reserved function for driver');
        }

        Object.keys(exportsMethods).forEach(function(key) {
            Constructor.prototype[key] = exportsMethods[key];
        });
    }

    if (specification.traits) {
        specification.traits.forEach(function(trait) {
            include(Constructor, trait);
        });
    }

    if (specification.states) {
        var states = specification.states;
        Object.keys(states).forEach(function(name) {
            var state = states[name];

            if (typeof state !== 'function') {
                throw new TypeError('State [' + name + '] is expected as a function');
            }
        });
    }

    return Constructor;
}

module.exports = driver;
