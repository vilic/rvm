/*!
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';

var driver = require('ruff-driver');

var REQUIRED = [
    'setup',
    'read',
    'readSync',
    'write',
    'writeSync'
];

//-----------------------------------------------------------------------------

var Uart = {};

Uart.BAUDRATE = Object.freeze({
   'b0'        :   0,
   'b50'       :   50,
   'b75'       :   75,
   'b110'      :   110,
   'b134'      :   134,
   'b150'      :   150,
   'b200'      :   200,
   'b300'      :   300,
   'b600'      :   600,
   'b1200'     :   1200,
   'b1800'     :   1800,
   'b2400'     :   2400,
   'b4800'     :   4800,
   'b9600'     :   9600,
   'b19200'    :   19200,
   'b38400'    :   38400,
   'b57600'    :   57600,
   'b115200'   :   115200,
   'b230400'   :   230400,
});

Uart.PARITY = Object.freeze({
    'none'  :   0,
    'odd'   :   1,
    'even'  :   2
});

Uart.FLOW_CONTROL = Object.freeze({
    'none'      :   0,
    'hardware'  :   1,
    'software'  :   2
});

var isInvalidBaudRate = function (baudRate) {
    return [Uart.BAUDRATE.b0,
            Uart.BAUDRATE.b50,
            Uart.BAUDRATE.b75,
            Uart.BAUDRATE.b110,
            Uart.BAUDRATE.b134,
            Uart.BAUDRATE.b150,
            Uart.BAUDRATE.b200,
            Uart.BAUDRATE.b300,
            Uart.BAUDRATE.b600,
            Uart.BAUDRATE.b1200,
            Uart.BAUDRATE.b1800,
            Uart.BAUDRATE.b2400,
            Uart.BAUDRATE.b4800,
            Uart.BAUDRATE.b9600,
            Uart.BAUDRATE.b19200,
            Uart.BAUDRATE.b38400,
            Uart.BAUDRATE.b57600,
            Uart.BAUDRATE.b115200,
            Uart.BAUDRATE.b230400].indexOf(baudRate) < 0;
};

var isInvalidParity = function (parity) {
    return ['none', 'odd', 'even'].indexOf(parity) < 0;
};

var isInvalidFlowControl = function (flowControl) {
    return ['none', 'hardware', 'software'].indexOf(flowControl) < 0;
};

var isInvalidDataBits = function (dataBits) {
    return [5, 6, 7, 8].indexOf(dataBits) < 0;
};

var isInvalidStopBits = function (stopBits) {
    return [1, 2].indexOf(stopBits) < 0;
};

//-----------------------------------------------------------------------------

function createActualSpec(specification) {
    var actualSpec = {
        attach: function(options) {
            specification._minBaudRate = options.getRequired('minBaudRate');
            specification._maxBaudRate = options.getRequired('maxBaudRate');

            var args = Array.prototype.slice.call(arguments);
            specification.attach.apply(this, args);
        },

        getDevice: function(key, inputs) {
            var baudRate = inputs.getOptional('baudRate', specification._minBaudRate);
            if (baudRate > specification._maxBaudRate ||
                baudRate < specification._minBaudRate) {
                throw new Error('Baud rate out of supported range');
            }

            var args = Array.prototype.slice.call(arguments);
            return specification.getDevice.apply(this, args);
        }
    };

    if (specification.detach) {
        actualSpec.detach = specification.detach;
    }

    var exports = specification.exports;

    actualSpec.exports = {
        setup: function(options) {
            if (options === null || typeof options !== 'object') {
                throw new Error('Invalid options');
            }

            ['baudRate', 'stopBits', 'dataBits'].forEach(function (key) {
                var value = options[key];
                if (typeof value === 'string') {
                    options[key] = parseInt(value);
                }
            });

            if (isInvalidBaudRate(options.baudRate)) {
                throw new Error('Invalid baud rate');
            }
            if (isInvalidStopBits(options.stopBits)) {
                throw new Error('Invalid stop bits');
            }
            if (isInvalidDataBits(options.dataBits)) {
                throw new Error('Invalid data bits');
            }
            if (isInvalidParity(options.parity)) {
                throw new Error('Invalid parity');
            }
            if (isInvalidFlowControl(options.flowControl)) {
                throw new Error('Invalid flow control');
            }

            return exports.setup.call(this, options);
        },

        read: function(callback) {
            if (typeof callback !== 'function') {
                throw new Error('Callback must be a function');
            }

            return exports.read.call(this, callback);
        },

        readSync: function(length, timeout) {
            if (typeof length !== 'number') {
                throw new Error('Length must be an integer');
            }

            if (typeof timeout !== 'number') {
                throw new Error('Timeout must be an integer');
            }

            return exports.readSync.call(this, length, timeout);
        },

        write: function(data, callback) {
            if (typeof data !== 'string' && !Buffer.isBuffer(data)) {
                throw new Error('Data must be either string or buffer');
            }

            if (typeof callback !== 'function') {
                throw new Error('Callback must be a function');
            }

            return exports.write.call(this, data, callback);
        },

        writeSync: function(data) {
            if (typeof data !== 'string' && !Buffer.isBuffer(data)) {
                throw new Error('Data must be either string or buffer');
            }

            return exports.writeSync.call(this, data, data);
        }
    };

    var targetExports = actualSpec.exports;
    for (var field in exports) {
        if (!targetExports.hasOwnProperty(field)) {
            targetExports[field] = exports[field];
        }
    }

    return actualSpec;
}

Uart.driver = function (specification) {
    REQUIRED.forEach(function (field) {
        if (typeof specification.exports[field] !== 'function') {
            throw new Error(field + ' is missing for UART');
        }
    });

    var spec = createActualSpec(specification);
    return driver(spec);
};

module.exports = Uart;
