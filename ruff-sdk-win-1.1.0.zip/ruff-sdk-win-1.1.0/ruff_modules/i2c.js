/*!
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';

var driver = require('ruff-driver');

var REQUIRED = [
    'readByte',
    'readWord',
    'readBytes',
    'writeByte',
    'writeWord',
    'writeBytes'
];

function toI2cValue(value) {
    return value & 0xFF;
}

function toI2cWriteValue(value) {
    return value & 0xFFFF;
}

function actualI2cSpec(specification) {
    var actualSpec = {};
    if (specification.attach) {
        actualSpec.attach = specification.attach;
    }

    if (specification.detach) {
        actualSpec.detach = specification.detach;
    }

    if (specification.getDevice) {
        actualSpec.getDevice = specification.getDevice;
    }

    var exports = specification.exports;

    actualSpec.exports = {
        readByte: function(command) {
            if (command === null || command === undefined || command === -1) {
                command = -1;
            } else {
                command = toI2cValue(command);
            }

            return exports.readByte.call(this, command);
        },

        readWord: function(command) {
            return exports.readWord.call(this, toI2cValue(command));
        },

        readBytes: function(command, length) {
            if (length > 512) {
                throw new Error('I2C read bytes length exceeds max length');
            }

            if (length <= 0) {
                throw new Error('I2C read bytes length should be greater than 0');
            }

            return exports.readBytes.call(this, toI2cValue(command), length);
        },

        writeByte: function(command, value) {
            if (command === null || command === undefined || command === -1) {
                command = -1;
            } else {
                command = toI2cValue(command);
            }
            return exports.writeByte.call(this, command, toI2cValue(value));
        },

        writeWord: function(command, value) {
            return exports.writeWord.call(this, toI2cValue(command), toI2cWriteValue(value));
        },

        writeBytes: function(command, values) {
            if (!Array.isArray(values)) {
                throw new Error('I2C write values are expected to be array');
            }

            var targets = values.map(function(value) {
                return toI2cValue(value);
            });

            return exports.writeBytes.call(this, toI2cValue(command), targets);
        }
    };

    var targetExports = actualSpec.exports;
    for (var field in exports) {
        if (!targetExports.hasOwnProperty(field)) {
            targetExports[field] = exports[field];
        }
    }

    return actualSpec;
}

var i2c = {
    driver: function(specification) {
        if (!specification.exports) {
            throw new Error('Required exports for I2C is missing');
        }

        REQUIRED.forEach(function(item) {
            if (typeof specification.exports[item] !== 'function') {
                throw new Error(item + ' is missing for I2C');
            }
        });

        var spec = actualI2cSpec(specification);
        return driver(spec);
    }
};

module.exports = i2c;
