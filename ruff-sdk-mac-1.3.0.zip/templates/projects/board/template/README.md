# Write App with Board `${name}`

You may provide some getting-started information on demo apps for this board.
