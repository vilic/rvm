var $titleLayer = $(document.createElement('div'))
    .addClass('title-layer')
    .hide()
    .appendTo(document.body);
$(document)
    .delegate('.desk .device .pin', 'mouseover', function (event) {
    var $pin = $(event.target);
    var title = $pin.attr('data-title');
    $titleLayer
        .text(title)
        .css({
        left: event.pageX + 'px',
        top: event.pageY + 'px'
    })
        .stop(true, false)
        .fadeIn();
})
    .delegate('.desk .device .pin', 'mouseout', function (event) {
    $titleLayer
        .stop(true, false)
        .fadeOut();
});
var devices = deskData
    .devices
    .map(function (deviceData) {
    var pins = deviceData
        .pins
        .map(function (data) { return new Pin(data.id, data.x, data.y); });
    return new Device(deviceData.id, deviceData.imageUrl, deviceData.width, deviceData.height, pins);
});
var desk = new Desk(devices, deskData.map);
desk.render();
$titleLayer.hide();
desk.$element.appendTo(document.body);
