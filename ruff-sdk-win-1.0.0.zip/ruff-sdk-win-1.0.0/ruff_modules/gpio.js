/**
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';

var driver = require('ruff-driver');
var mixin = require('util').mixin;

function isin(a, b) {
    return (a.indexOf(b) >= 0);
}

var Gpio = {};

// Direction Types
Gpio.IN  = 0;
Gpio.OUT = 1;
Gpio.OUT_LOW = 2;
Gpio.OUT_HIGH = 3;

var gpioDirections = {
    'in'       : Gpio.IN,
    'out'      : Gpio.OUT,
    'out_low'  : Gpio.OUT_LOW,
    'out_high' : Gpio.OUT_HIGH
};

Gpio.EDGE_NONE      = 0;
Gpio.EDGE_RISING    = 1;
Gpio.EDGE_FALLING   = 2;
Gpio.EDGE_BOTH      = 3;
Gpio.UNINIT_STATE   = -1;

var gpioEdges = {
    'falling' : Gpio.EDGE_FALLING,
    'rising'  : Gpio.EDGE_RISING,
    'both'    : Gpio.EDGE_BOTH,
    'none'    : Gpio.EDGE_NONE
};

var isValidDirection = function(direction) {
    var validDirction = [Gpio.IN,
                         Gpio.OUT,
                         Gpio.OUT_LOW,
                         Gpio.OUT_HIGH];
    return(isin(validDirction, direction));
};

var isValidEdge = function(edgeMode) {
    var validEdge     = [Gpio.EDGE_NONE,
                         Gpio.EDGE_RISING,
                         Gpio.EDGE_FALLING,
                         Gpio.EDGE_BOTH];
    return (isin(validEdge, edgeMode));
};

Gpio.toDirection = function(directionText) {
    return gpioDirections[directionText];
};

Gpio.toEdge = function(edgeStr) {
    return gpioEdges[edgeStr];
};

var GpioBase = function (options) {
    this._pin       = options.getRequired('pin');
    this._direction = Gpio.UNINIT_STATE;
    this._edge      = Gpio.UNINIT_STATE;
};

GpioBase.prototype.getPin = function() {
    return this._pin;
};

GpioBase.prototype.getDiection = function() {
    return this._direction;
};

GpioBase.prototype.getEdge = function() {
    return this._edge;
};

var REQUIRED = [
    'read',
    'write',
    'setDirection',
    'setEdge',
    'setActiveLow'
];

function actualGpioSpec(specification) {
    var actualSpec = {
        attach: function() {
            var args = Array.prototype.slice.call(arguments);
            GpioBase.apply(this, args);
            specification.attach.apply(this, args);
        }
    };

    if (specification.detach) {
        actualSpec.detach = specification.detach;
    }

    if (specification.getDevice) {
        actualSpec.getDevice = specification.getDevice;
    }

    var exports = specification.exports;

    actualSpec.exports = {
        setDirection: function(direction) {
            if (this._direction === direction) {
                return false;
            }

            if (!isValidDirection(direction)) {
                throw new Error('Try to set invalid direction [' + direction + '] to GPIO');
            }

            this._direction = direction;

            exports.setDirection.call(this, direction);
        },

        setEdge: function(edge) {
            if (this._direction !== Gpio.IN) {
                throw new Error('Edge can only be set for GPIO with IN direction');
            }

            if (this._edge === edge) {
                return;
            }

            if (!isValidEdge(edge)) {
                throw new Error('Try to set invalid edge [' + edge + '] to GPIO');
            }

            this._edge = edge;
            exports.setEdge.call(this, edge);
        },

        write: function(value) {
            if (this._direction === Gpio.IN) {
                throw new Error('Not allowed to write with IN direction for GPIO');
            }

            exports.write.call(this, value);
        }
    };

    var targetExports = actualSpec.exports;
    for (var field in exports) {
        if (!targetExports.hasOwnProperty(field)) {
            targetExports[field] = exports[field];
        }
    }

    return actualSpec;
}

Gpio.driver = function(specification) {
    if (!specification.exports) {
        throw new Error('Required exports for GPIO is missing');
    }

    REQUIRED.forEach(function(item) {
        if (typeof specification.exports[item] !== 'function') {
            throw new Error(item + ' is missing for GPIO');
        }
    });

    var spec = actualGpioSpec(specification);
    var driverClass = driver(spec);
    mixin(driverClass, [GpioBase]);

    return driverClass;
};

module.exports = Gpio;
