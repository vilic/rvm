/**
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';
/* jshint ignore:start */

// This is a free list to avoid creating so many of the same object.
exports.FreeList = function(name, max, constructor) {
    this.name = name;
    this.constructor = constructor;
    this.max = max;
    this.list = [];
};


exports.FreeList.prototype.alloc = function() {
    return this.list.length ? this.list.shift() :
        this.constructor.apply(this, arguments);
};


exports.FreeList.prototype.free = function(obj) {
    if (this.list.length < this.max) {
        this.list.push(obj);
        return true;
    }
    return false;
};
