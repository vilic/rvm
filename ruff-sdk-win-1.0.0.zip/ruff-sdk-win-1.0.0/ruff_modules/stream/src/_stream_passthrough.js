/**
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

// a passthrough stream.
// basically just the most minimal sort of Transform stream.
// Every written chunk gets output as-is.

'use strict';

var Transform = require('./_stream_transform.js');
var util      = require('util');

function PassThrough(options) {
	if (!(this instanceof PassThrough)) {
		return new PassThrough(options);
	}

	Transform.call(this, options);
}

util.inherits(PassThrough, Transform);

PassThrough.prototype._transform = function (chunk, encoding, cb) {
	// get the output just as same as input.
	cb(null, chunk);
};

module.exports = PassThrough;
