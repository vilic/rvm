/*!
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';
var path = require('path');
var EventEmitter = require('events').EventEmitter;
var anyMock = require('ruff-mock').anyMock;

function InputOptions(options) {
    this._options = options || {};
}

InputOptions.prototype.getRequired = function(key) {
    if (!this._options.hasOwnProperty(key)) {
        throw new Error('Required property [' + key + '] is missing');
    }

    return this._options[key];
};

InputOptions.prototype.getOptional = function(key, defaultValue) {
    if (!this._options.hasOwnProperty(key)) {
        return defaultValue;
    }

    return this._options[key];
};

InputOptions.prototype.setValue = function(key, value) {
    this._options[key] = value;
};

function safeRequire(filename) {
    try {
        return require(filename);
    } catch (error) {
        if (error instanceof SyntaxError) {
            throw new SyntaxError('Fail to parse ' + filename + ', ' + error.message);
        }

        throw error;
    }
}

function DriverRunner() {}

function getEventMock() {
    var re = anyMock();
    var obj = new EventEmitter();
    for (var fm in obj) {
        if (obj[fm] === 'constructor') {
            continue;
        } else {
            re[fm] = obj[fm];
        }
    }
    return re;
}

function Context(args) {
    this.args = args;
}

Context.prototype.arg = function(name) {
    if (name in this.args) {
        return this.args[name];
    }

    throw new Error('Unknown arg: ' + name);
};

DriverRunner.prototype.run = function(driverPath, callback) {
    var driverConfig = require(path.join(driverPath, 'driver.json'));
    var driverInputs = driverConfig.inputs;
    var driverArgs = driverConfig.args;
    var mockDrivers = {};

    for (var key in driverInputs) {
        mockDrivers[key] = getEventMock();
    }

    for (var driverArg in driverArgs) {
        mockDrivers[driverArg] = getEventMock();
    }

    var Entry = safeRequire(path.join(driverPath, 'src', 'index.js'));

    var device = new Entry(new InputOptions(mockDrivers), {
        extras: Array.prototype.slice.call(arguments, 2)
    });

    callback(device, new Context(mockDrivers));
};

module.exports = new DriverRunner();