/**
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';

exports.LISTENING    = 'listening';
exports.CONNECTION   = 'connection';
exports.DATA         = 'data';
exports.CONNECT      = 'connect';
exports.LOOKUP       = 'lookup';
exports.DRAIN        = 'drain';
exports.SOCKETFINISH = '_socketFinish';
exports.SOCKETEND    = '_socketEnd';
exports.END          = 'end';
exports.ERROR        = 'error';
exports.CLOSE        = 'close';
