/**
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';
/* jshint ignore:start */
var netEvents = require('./net-events.js');
var netUtil   = require('./net-util.js');
var dns       = require('dns');

function socketConnectWrap(proto) {
    function validateConnectArgs(localAddress, localPort, port) {
        if (localAddress && !exports.isIP(localAddress)) {
            throw new TypeError('localAddress must be a valid IP: ' + localAddress);
        }
        if (localPort && typeof localPort !== 'number') {
            throw new TypeError('localPort should be a number: ' + localPort);
        }
        if (typeof port !== 'undefined') {
            if (typeof port !== 'number' && typeof port !== 'string') {
                throw new TypeError('port should be a number or string: ' + port);
            }
            if (!netUtil.isLegalPort(port)) {
                throw new RangeError('port should be >= 0 and < 65536: ' + port);
            }
        }
    }

    function validLookupOption(options) {
        if (!options.lookup) {
            options.lookup = dns.lookup;
        }
        if (typeof options.lookup !== 'function') {
            throw new TypeError('options.lookup should be a function.');
        }
        if (!options.family) {
            options.family = 4;
        }
        if (options.family !== 4 && options.family !== 6) {
            throw new TypeError('only support family 4 or 6.');
        }
    }

    function bindToLocal(localAddress, localPort, addressType, client) {
        if (localAddress || localPort) {
            if (addressType === 4) {
                localAddress = localAddress || '0.0.0.0';
            } else if (addressType === 6) {
                localAddress = localAddress || '::';
            } else {
                client._destroy(new TypeError('Invalid addressType: ' + addressType));
                return false;
            }
            try {
                uv.tcp_bind(client._uvHandle, localAddress, localPort)
            } catch (err) {
                self._destroy(netUtil.exceptionWithHostPort(err, 'bind', localAddress, localPort));
                return false;
            }
        }
        return true;
    }

    function connectToHost(client, host, port) {
        if (!client._uvHandle) {
            client._uvHandle = uv.new_tcp();
        }
        try {
            uv.tcp_connect(client._uvHandle, host, port, netUtil.wrapCb(client, 'connect', function () {
                client._connecting = false;
                client.readable    = true;

                client.emit(netEvents.CONNECT);
                client.readStart();
            }), host, port);
        } catch (error) {
            netUtil.cleanupWhenError(client, 'connect', error, host, port);
        }
    }

    function connect(client, host, port, addressType, localAddress, localPort) {
        if (bindToLocal(localAddress, localPort, addressType, client)) {
            connectToHost(client, host, port);
        }
    }

    function connectErrorNT(socket, err) {
        socket.emit(netEvents.ERROR, err);
        socket._destroy();
    }

    // net.createConnection() creates a net.Socket object and immediately calls net.Socket.connect() on it (that's us).
    // There are no event listeners registered yet so defer the error event to the next tick.
    function handleLookupError(options, socket, err) {
        err.host    = options.host;
        err.port    = options.port;
        err.message = err.message + ' ' + options.host + ':' + options.port;
        process.nextTick(connectErrorNT, socket, err);
    }

    proto._lookupAndConnect = function (options) {
        var client = this;

        function connectToIP(addressType) {
            process.nextTick(function () {
                if (client._connecting) {
                    connect(client, host, port, addressType, localAddress, localPort);
                }
            });
        }

        function connectUseDNS() {
            validLookupOption(options);
            var lookup = options.lookup;
            lookup(host, {
                family: options.family,
                hints: 0
            }, function (err, ip, addressType) {
                client.emit(netEvents.LOOKUP, err, ip, addressType);
                // It's possible we were destroyed while looking this up.
                // it would be great if we could cancel the promise returned by the look up.
                if (client._connecting) {
                    err ? handleLookupError(options, client, err) : connect(client, ip, port, addressType, localAddress, localPort);
                }
            });
        }

        var host         = options.host || '0.0.0.0';
        var port         = options.port;
        var localAddress = options.localAddress;
        var localPort    = options.localPort;
        validateConnectArgs(localAddress, localPort, port);

        port |= 0;
        var addressType = netUtil.isIp(host);
        addressType ? connectToIP(addressType) : connectUseDNS();
    }
}

exports.socketConnectWrap = socketConnectWrap;
