/**
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';
/* jshint ignore:start */
exports.normalizeCreateServerArgs = function (options, connectionListener) {
    // compatible with different parameter patterns.
    if (typeof options === 'function') {
        // when user doesn't pass options param.
        connectionListener = options;
        options            = {};
    } else {
        // give a default value for 'options' param.
        options = options || {};
    }
    return [options, connectionListener];
};

exports.normalizeConnectArgs = function (args) {
    var options = {};

    // first, extract port and host part from arguments.
    if (args[0] !== null && typeof args[0] === 'object') {
        // connect(options, [cb])
        options = args[0];
    } else {
        // connect(port, [host], [cb])
        options.port = args[0];
        if (typeof args[1] === 'string') {
            // connect(port, host, [cb])
            options.host = args[1];
        }
    }

    // if last arg is a function, use it as callback.
    var cb = args[args.length - 1];
    return typeof cb === 'function' ? [options, cb] : [options];
};

function isPortSpecified(args) {
    return !(args.length === 0 || typeof args[0] === 'function');
}

exports.normalizeListenArgs = function (args) {
    var port    = null;
    var host    = '0.0.0.0';
    var backlog = 128;

    if (isPortSpecified(args)) {
        if (typeof args[0] === 'number' && !isNaN(args[0])) {
            // first argument is port.
            port = Number(args[0]);

            // if second is host(string).
            if (typeof args[1] === 'string' && require('./net-util.js').isIp(args[1])) {
                host = args[1];
            }

            // if second/third is backlog(number).
            if (typeof args[1] === 'number') {
                backlog = args[1];
            } else if (typeof args[2] === 'number') {
                backlog = args[2];
            }
        } else {
            // first argument is options.
            port    = args[0].port || port;
            host    = args[0].host || host;
            backlog = args[0].backlog || backlog;
        }
    }
    return [host, port, backlog];
};