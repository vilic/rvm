/**
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';

function isFunction(func) {
    return func && typeof func === 'function';
}

function check(proto) {
    if (!isFunction(proto.setFrequency)) {
        throw new Error('setFrequency function has not implemented');
    }

    if (!isFunction(proto.setDuty)) {
        throw new Error('setDuty function has not implemented');
    }
}

function driver(specification) {
    var Constructor = function() {
        this.__attach__.apply(this, Array.prototype.slice.call(arguments, 1));
    };

    if (specification.attach === undefined) {
        throw new Error('attach must be specified');
    }

    Constructor.prototype.__attach__ = specification.attach;

    if (specification.exports) {
        Object.keys(specification.exports).forEach(function(key) {
            Constructor.prototype[key] = specification.exports[key];
        });
    }

    check(Constructor.prototype);

    Constructor.prototype.constructor = Constructor;
    return Constructor;
}

exports.driver = driver;
