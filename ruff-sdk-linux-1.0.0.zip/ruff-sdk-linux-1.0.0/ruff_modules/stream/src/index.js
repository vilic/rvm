/**
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';

var EE = require('events');
var util = require('util');

function Stream() {
    EE.call(this);
}

util.inherits(Stream, EE);


Stream.Stream = Stream;

module.exports = Stream;

//TODO process.nextTick
process.nextTick = function (callback) {
    var _arguments = arguments;
    require('timers').setTimeout(function () {
        callback.apply(null, Array.prototype.slice.call(_arguments, 1));
    },0);
};

Stream.Readable = require('./_stream_readable.js');
Stream.Writable = require('./_stream_writable.js');
Stream.Duplex = require('./_stream_duplex.js');
Stream.Transform = require('./_stream_transform.js');

Stream.PassThrough = require('./_stream_passthrough.js');