/**
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';
/* jshint ignore:start */

var assert = require('assert').ok;
var Stream = require('stream');
var util = require('util');
//var internalUtil = require('internal/util');
var Buffer = require('buffer').Buffer;
var common = require('./http-common.js');
var InnerWrap = require('./http-outgoing-inner.js').outgoingInnerWrap;
var EndWrap = require('./http-outgoing-end.js').outgoingEndWrap;

var automaticHeaders = {
    connection: true,
    'content-length': true,
    'transfer-encoding': true,
    date: true
};

function OutgoingMessage() {
    Stream.call(this);

    // Queue that holds all currently pending data, until the response will be
    // assigned to the socket (until it will its turn in the HTTP pipeline).
    this.output = [];
    this.outputEncodings = [];
    this.outputCallbacks = [];

    // `outputSize` is an approximate measure of how much data is queued on this
    // response. `_onPendingData` will be invoked to update similar global
    // per-connection counter. That counter will be used to pause/unpause the
    // TCP socket and HTTP Parser and thus handle the backpressure.
    this.outputSize = 0;

    this.writable = true;

    this._last = false;
    this.chunkedEncoding = false;
    this.shouldKeepAlive = true;
    this.useChunkedEncodingByDefault = true;
    this.sendDate = false;
    this._removedHeader = {};

    this._contentLength = null;
    this._hasBody = true;
    this._trailer = '';

    this.finished = false;
    this._headerSent = false;

    this.socket = null;
    this.connection = null;
    this._header = null;
    this._headers = null;
    this._headerNames = {};

    this._onPendingData = null;
}

util.inherits(OutgoingMessage, Stream);

OutgoingMessage.prototype.setHeader = function(name, value) {
    if (!common._checkIsHttpToken(name))
        throw new TypeError('Header name must be a valid HTTP Token ["' + name + '"]');
    if (typeof name !== 'string')
        throw new TypeError('`name` should be a string in setHeader(name, value).');
    if (value === undefined)
        throw new Error('`value` required in setHeader("' + name + '", value).');
    if (this._header)
        throw new Error('Can\'t set headers after they are sent.');

    if (this._headers === null)
        this._headers = {};

    var key = name.toLowerCase();
    this._headers[key] = value;
    this._headerNames[key] = name;

    if (automaticHeaders[key])
        this._removedHeader[key] = false;
};

OutgoingMessage.prototype.getHeader = function(name) {
    if (arguments.length < 1) {
        throw new Error('`name` is required for getHeader(name).');
    }

    if (!this._headers) return;

    var key = name.toLowerCase();
    return this._headers[key];
};

OutgoingMessage.prototype.flushHeaders = function() {
    if (!this._header) {
        this._implicitHeader();
    }

    // Force-flush the headers.
    this._send('');
};

InnerWrap(OutgoingMessage.prototype);
EndWrap(OutgoingMessage.prototype);

exports.OutgoingMessage = OutgoingMessage;