/**
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';
/* jshint ignore:start */
var httpEvents = require('./http-events.js');
var common     = require('./http-common.js');

function clientInnerWrap(proto) {
    proto._deferToConnect = function (method, arguments_, cb) {
        // This function is for calls that need to happen once the socket is
        // connected and writable. It's an important promisy thing for all the socket
        // calls that happen either now (when a socket is assigned) or
        // in the future (when a socket gets assigned out of the pool and is
        // eventually writable).
        var self = this;

        function callSocketMethod() {
            if (method) {
                self.socket[method].apply(self.socket, arguments_);
            }

            if (typeof cb === 'function') {
                cb();
            }
        }

        var onSocket = function () {
            if (self.socket.writable) {
                callSocketMethod();
            } else {
                self.socket.once(httpEvents.CONNECT, callSocketMethod);
            }
        };

        if (!self.socket) {
            self.once(httpEvents.SOCKET, onSocket);
        } else {
            onSocket();
        }
    };

    proto._implicitHeader = function () {
        this._storeHeader(this.method + ' ' + this.path + ' HTTP/1.1\r\n', this._renderHeaders());
    };
}

exports.clientInnerWrap = clientInnerWrap;