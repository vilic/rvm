/**
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

'use strict';
/* jshint ignore:start */

exports._extend = function (origin, add) { // Don't do anything if add isn't an object
    for(var key in add) {
        origin[key] = add[key];
    }
    return origin;
};