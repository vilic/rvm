'use strict';

$.ready(function (error) {
    if (error) {
        console.error(error);
        return;
    }

    // ...
});

$.end(function () {
    // ...
});
