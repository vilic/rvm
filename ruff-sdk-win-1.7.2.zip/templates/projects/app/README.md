# Ruff Application
