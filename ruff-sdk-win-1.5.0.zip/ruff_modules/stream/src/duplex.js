/*!
 * Copyright (c) 2015-2016, Nanchao, Inc.
 * All rights reserved.
 */

// a duplex stream is just a stream that is both readable and writable.
// Since JS doesn't have multiple prototypal inheritance, this class
// prototypally inherits from Readable, and then parasitically from
// Writable.

'use strict';

module.exports = Duplex;

var util = require('util');
var Readable = require('./readable.js');
var Writable = require('./writable.js');

util.inherits(Duplex, Readable);

var keys = Object.keys(Writable.prototype);
for (var v = 0; v < keys.length; v++) {
    var method = keys[v];
    if (!Duplex.prototype[method])
        Duplex.prototype[method] = Writable.prototype[method];
}

function Duplex(options) {
    if (!(this instanceof Duplex))
        return new Duplex(options);

    Readable.call(this, options);
    Writable.call(this, options);

    if (options && options.readable === false)
        this.readable = false;

    if (options && options.writable === false)
        this.writable = false;

    this.allowHalfOpen = true;
    if (options && options.allowHalfOpen === false)
        this.allowHalfOpen = false;

    this.once('end', onend);
}

// the no-half-open enforcer
function onend() {
    // if we allow half-open state, or if the writable side ended,
    // then we're ok.
    if (this.allowHalfOpen || this._writableState.ended)
        return;

    // no more data can be written.
    // But allow more writes to happen in this tick.
    process.nextTick(onEndNT, this);
}

function onEndNT(self) {
    self.end();
}